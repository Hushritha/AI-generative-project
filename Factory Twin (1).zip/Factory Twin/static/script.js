        // Configuration
        const TEMP_THRESHOLD_WARNING = 50;
        const TEMP_THRESHOLD_DANGER = 70;
        const VIBRATION_THRESHOLD_WARNING = 30;
        const VIBRATION_THRESHOLD_DANGER = 50;

        // State management
        let machineData = [];
        let nextMachineId = 1;
        let selectedMachineId = null;
        let rotationY = 0;

        // Create machine cube with enhanced 3D design
        function createMachineCube(machine) {
            const cube = document.createElement('div');
            cube.className = 'machine-cube';
            cube.id = `machine-${machine.id}`;

            // Determine machine status
            let statusClass = 'normal';
            if (machine.temperature > TEMP_THRESHOLD_DANGER) {
                statusClass = 'danger';
            } else if (machine.temperature > TEMP_THRESHOLD_WARNING) {
                statusClass = 'warning';
            }

            // Create all faces of the cube
            const faces = ['front', 'back', 'left', 'right', 'top', 'bottom'];
            
            faces.forEach(face => {
                const faceElement = document.createElement('div');
                faceElement.className = `face ${face}`;
                
                // Add content to front face
                if (face === 'front') {
                    // Machine header with title and status indicator
                    const machineHeader = document.createElement('div');
                    machineHeader.className = 'machine-header';
                    
                    const machineTitle = document.createElement('div');
                    machineTitle.className = 'machine-title';
                    machineTitle.textContent = `Machine ${machine.id}`;
                    
                    const machineStatus = document.createElement('div');
                    machineStatus.className = `machine-status ${statusClass}`;
                    
                    machineHeader.appendChild(machineTitle);
                    machineHeader.appendChild(machineStatus);
                    
                    // Machine stats with visual indicators
                    const statsDiv = document.createElement('div');
                    statsDiv.className = 'machine-stats';
                    
                    // Temperature stat
                    const tempStat = document.createElement('div');
                    tempStat.className = 'stat-item';
                    
                    const tempLabel = document.createElement('div');
                    tempLabel.className = 'stat-label';
                    tempLabel.innerHTML = 'Temperature <span>' + machine.temperature + '°C</span>';
                    
                    const tempBar = document.createElement('div');
                    tempBar.className = 'stat-bar';
                    
                    const tempBarFill = document.createElement('div');
                    tempBarFill.className = `stat-bar-fill ${statusClass}`;
                    tempBarFill.style.width = `${Math.min(100, (machine.temperature / 100) * 100)}%`;
                    
                    tempBar.appendChild(tempBarFill);
                    tempStat.appendChild(tempLabel);
                    tempStat.appendChild(tempBar);
                    
                    // Vibration stat
                    const vibStat = document.createElement('div');
                    vibStat.className = 'stat-item';
                    
                    const vibLabel = document.createElement('div');
                    vibLabel.className = 'stat-label';
                    vibLabel.innerHTML = 'Vibration <span>' + machine.vibration + ' Hz</span>';
                    
                    const vibBar = document.createElement('div');
                    vibBar.className = 'stat-bar';
                    
                    // Determine vibration status
                    let vibStatusClass = 'normal';
                    if (machine.vibration > VIBRATION_THRESHOLD_DANGER) {
                        vibStatusClass = 'danger';
                    } else if (machine.vibration > VIBRATION_THRESHOLD_WARNING) {
                        vibStatusClass = 'warning';
                    }
                    
                    const vibBarFill = document.createElement('div');
                    vibBarFill.className = `stat-bar-fill ${vibStatusClass}`;
                    vibBarFill.style.width = `${Math.min(100, (machine.vibration / 100) * 100)}%`;
                    
                    vibBar.appendChild(vibBarFill);
                    vibStat.appendChild(vibLabel);
                    vibStat.appendChild(vibBar);
                    
                    // Add stats to the stats container
                    statsDiv.appendChild(tempStat);
                    statsDiv.appendChild(vibStat);
                    
                    // Assemble the front face
                    faceElement.appendChild(machineHeader);
                    faceElement.appendChild(statsDiv);
                }
                
                // Add content to back face
                if (face === 'back') {
                    const backContent = document.createElement('div');
                    backContent.innerHTML = `
                        <div class="machine-header">
                            <div class="machine-title">Machine ${machine.id} Details</div>
                        </div>
                        <div class="machine-stats">
                            <div class="stat-item">
                                <div class="stat-label">Status</div>
                                <div class="stat-value">${getStatusText(machine)}</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-label">Last Updated</div>
                                <div class="stat-value">${new Date().toLocaleTimeString()}</div>
                            </div>
                        </div>
                    `;
                    faceElement.appendChild(backContent);
                }
                
                cube.appendChild(faceElement);
            });

            // Apply visual effects based on machine state
            if (machine.temperature > TEMP_THRESHOLD_DANGER) {
                cube.classList.add('high-temp');
            }
            if (machine.vibration > VIBRATION_THRESHOLD_DANGER) {
                cube.classList.add('high-vibration');
            }

            // Add click event to select machine and show details
            cube.addEventListener('click', () => {
                // Deselect previously selected machine
                if (selectedMachineId) {
                    const prevSelected = document.getElementById(`machine-${selectedMachineId}`);
                    if (prevSelected) {
                        prevSelected.classList.remove('selected');
                    }
                }
                
                // Select this machine
                selectedMachineId = machine.id;
                cube.classList.add('selected');
                
                // Highlight the corresponding row in the data table
                if (dataTable) {
                    dataTable.selectRow(machine.id);
                }
                
                // Show machine details
                showMachineDetails(machine);
            });

            return cube;
        }

        // Show machine details panel
        function showMachineDetails(machine) {
            const detailsPanel = document.getElementById('machine-details');
            const detailsContent = document.getElementById('details-content');
            
            // Create details content
            detailsContent.innerHTML = `
                <div class="detail-group">
                    <div class="detail-label">Machine ID</div>
                    <div class="detail-value">${machine.id}</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Temperature</div>
                    <div class="detail-value">${machine.temperature}°C</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Vibration</div>
                    <div class="detail-value">${machine.vibration} Hz</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Status</div>
                    <div class="detail-value">${getStatusText(machine)}</div>
                </div>
                <div class="detail-group">
                    <div class="detail-label">Last Updated</div>
                    <div class="detail-value">${new Date().toLocaleTimeString()}</div>
                </div>
            `;
            
            // Show the panel
            detailsPanel.classList.add('active');
        }
        
        // Get status text based on machine data
        function getStatusText(machine) {
            if (machine.temperature > TEMP_THRESHOLD_DANGER || machine.vibration > VIBRATION_THRESHOLD_DANGER) {
                return 'Critical';
            } else if (machine.temperature > TEMP_THRESHOLD_WARNING || machine.vibration > VIBRATION_THRESHOLD_WARNING) {
                return 'Warning';
            } else {
                return 'Operational';
            }
        }

        // Close machine details panel
        document.getElementById('close-details').addEventListener('click', () => {
            document.getElementById('machine-details').classList.remove('active');
        });

        // Render factory visualization
        function renderFactory() {
            const factoryContainer = document.getElementById('factory-container');
            factoryContainer.innerHTML = '';

            machineData.forEach(machine => {
                const machineCube = createMachineCube(machine);
                factoryContainer.appendChild(machineCube);
            });
        }

        // Create data table with enhanced styling
        let dataTable;
        function createDataTable() {
            if (dataTable) {
                dataTable.destroy();
            }
            
            dataTable = new Tabulator("#data-controls", {
                data: machineData,
                layout: "fitColumns",
                selectable: 1,
                rowClick: function(e, row) {
                    // Deselect previously selected machine
                    if (selectedMachineId) {
                        const prevSelected = document.getElementById(`machine-${selectedMachineId}`);
                        if (prevSelected) {
                            prevSelected.classList.remove('selected');
                        }
                    }
                    
                    // Select the clicked machine
                    const machineId = row.getData().id;
                    selectedMachineId = machineId;
                    const machineCube = document.getElementById(`machine-${machineId}`);
                    if (machineCube) {
                        machineCube.classList.add('selected');
                        
                        // Show machine details
                        const machine = machineData.find(m => m.id === machineId);
                        if (machine) {
                            showMachineDetails(machine);
                        }
                    }
                },
                columns: [
                    {title: "ID", field: "id", width: 80},
                    {
                        title: "Temperature (°C)", 
                        field: "temperature", 
                        editor: "number",
                        cellEdited: updateMachine,
                        formatter: function(cell) {
                            const value = cell.getValue();
                            let color = "var(--success-color)";
                            
                            if (value > TEMP_THRESHOLD_DANGER) {
                                color = "var(--danger-color)";
                            } else if (value > TEMP_THRESHOLD_WARNING) {
                                color = "var(--warning-color)";
                            }
                            
                            return `<span style="color: ${color}; font-weight: 600;">${value}</span>`;
                        }
                    },
                    {
                        title: "Vibration (Hz)", 
                        field: "vibration", 
                        editor: "number",
                        cellEdited: updateMachine,
                        formatter: function(cell) {
                            const value = cell.getValue();
                            let color = "var(--success-color)";
                            
                            if (value > VIBRATION_THRESHOLD_DANGER) {
                                color = "var(--danger-color)";
                            } else if (value > VIBRATION_THRESHOLD_WARNING) {
                                color = "var(--warning-color)";
                            }
                            
                            return `<span style="color: ${color}; font-weight: 600;">${value}</span>`;
                        }
                    },
                    {
                        title: "Status", 
                        field: "id", 
                        formatter: function(cell) {
                            const row = cell.getRow().getData();
                            let status = "Operational";
                            let color = "var(--success-color)";
                            
                            if (row.temperature > TEMP_THRESHOLD_DANGER || row.vibration > VIBRATION_THRESHOLD_DANGER) {
                                status = "Critical";
                                color = "var(--danger-color)";
                            } else if (row.temperature > TEMP_THRESHOLD_WARNING || row.vibration > VIBRATION_THRESHOLD_WARNING) {
                                status = "Warning";
                                color = "var(--warning-color)";
                            }
                            
                            return `<span style="color: ${color}; font-weight: 600;">${status}</span>`;
                        }
                    },
                    {
                        title: "Actions",
                        formatter: function() {
                            return `
                                <button class="btn" style="padding: 4px 8px; font-size: 12px;">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                    </svg>
                                    Edit
                                </button>
                            `;
                        },
                        width: 100,
                        hozAlign: "center",
                        cellClick: function(e, cell) {
                            e.stopPropagation();
                            const row = cell.getRow();
                            row.toggleSelect();
                        }
                    }
                ]
            });
        }

        // Update machine state with enhanced visual feedback
        function updateMachine(cell) {
            const row = cell.getRow();
            const updatedMachineData = row.getData();
            const machineElement = document.getElementById(`machine-${updatedMachineData.id}`);
            
            if (!machineElement) return;
            
            // Find the machine in our data array and update it
            const machineIndex = machineData.findIndex(m => m.id === updatedMachineData.id);
            if (machineIndex !== -1) {
                machineData[machineIndex] = updatedMachineData;
            }
            
            // Create a new machine cube with updated data
            const newMachineCube = createMachineCube(updatedMachineData);
            
            // Replace the old cube with the new one
            machineElement.parentNode.replaceChild(newMachineCube, machineElement);
            
            // If this was the selected machine, update details
            if (selectedMachineId === updatedMachineData.id) {
                showMachineDetails(updatedMachineData);
            }
        }

        // Rotate view controls
        document.getElementById('rotate-left').addEventListener('click', () => {
            rotationY -= 15;
            document.getElementById('factory-container').style.transform = 
                `rotateX(20deg) rotateZ(${rotationY}deg)`;
        });
        
        document.getElementById('rotate-right').addEventListener('click', () => {
            rotationY += 15;
            document.getElementById('factory-container').style.transform = 
                `rotateX(20deg) rotateZ(${rotationY}deg)`;
        });

        // Add machine with enhanced random data
        document.getElementById('add-machine').addEventListener('click', () => {
            const newMachine = {
                id: nextMachineId++,
                temperature: Math.floor(Math.random() * 100),
                vibration: Math.floor(Math.random() * 100)
            };

            machineData.push(newMachine);
            renderFactory();
            createDataTable();
        });

        // Remove machine with animation
        document.getElementById('remove-machine').addEventListener('click', () => {
            if (machineData.length > 0) {
                // If a machine is selected, remove that one
                if (selectedMachineId) {
                    const index = machineData.findIndex(m => m.id === selectedMachineId);
                    if (index !== -1) {
                        // Animate removal
                        const machineElement = document.getElementById(`machine-${selectedMachineId}`);
                        if (machineElement) {
                            machineElement.style.transform = 'scale(0.5) translateY(50px)';
                            machineElement.style.opacity = '0';
                            
                            setTimeout(() => {
                                machineData.splice(index, 1);
                                selectedMachineId = null;
                                document.getElementById('machine-details').classList.remove('active');
                                renderFactory();
                                createDataTable();
                            }, 300);
                            return;
                        }
                    }
                }
                
                // If no machine is selected or the selected one wasn't found, remove the last one
                machineData.pop();
                renderFactory();
                createDataTable();
            }
        });

        // Simulate failure button
        document.getElementById('simulate-failure').addEventListener('click', () => {
            if (machineData.length > 0) {
                // Select a random machine or use the selected one
                const targetIndex = selectedMachineId 
                    ? machineData.findIndex(m => m.id === selectedMachineId)
                    : Math.floor(Math.random() * machineData.length);
                
                if (targetIndex !== -1) {
                    // Simulate critical failure with high temperature and vibration
                    machineData[targetIndex].temperature = Math.floor(Math.random() * 30) + 80; // 80-110
                    machineData[targetIndex].vibration = Math.floor(Math.random() * 30) + 70; // 70-100
                    
                    renderFactory();
                    createDataTable();
                    
                    // Flash the affected machine
                    const machineElement = document.getElementById(`machine-${machineData[targetIndex].id}`);
                    if (machineElement) {
                        machineElement.style.animation = 'none';
                        setTimeout(() => {
                            machineElement.style.animation = '';
                        }, 10);
                    }
                }
            }
        });

        // Reset simulation
        document.getElementById('reset-simulation').addEventListener('click', () => {
            // Reset all machines to normal values
            machineData.forEach(machine => {
                machine.temperature = Math.floor(Math.random() * 30) + 20; // 20-50
                machine.vibration = Math.floor(Math.random() * 20) + 10; // 10-30
            });
            
            renderFactory();
            createDataTable();
        });

        // Export data
        document.getElementById('export-data').addEventListener('click', () => {
            // Create CSV content
            let csvContent = "data:text/csv;charset=utf-8,";
            csvContent += "Machine ID,Temperature (°C),Vibration (Hz),Status\n";
            
            machineData.forEach(machine => {
                const status = getStatusText(machine);
                csvContent += `${machine.id},${machine.temperature},${machine.vibration},${status}\n`;
            });
            
            // Create download link
            const encodedUri = encodeURI(csvContent);
            const link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            link.setAttribute("download", "factory_data.csv");
            document.body.appendChild(link);
            
            // Trigger download
            link.click();
            document.body.removeChild(link);
        });

        // Import data from Excel or CSV
        document.getElementById('import-data').addEventListener('click', () => {
            document.getElementById('file-input').click();
        });

        document.getElementById('file-input').addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (!file) return;
            
            const reader = new FileReader();
            const fileName = file.name.toLowerCase();
            
            if (fileName.endsWith('.csv')) {
                reader.onload = (event) => {
                    const csvData = event.target.result;
                    processCSVData(csvData);
                };
                reader.readAsText(file);
            } else if (fileName.endsWith('.xlsx') || fileName.endsWith('.xls')) {
                reader.onload = (event) => {
                    const data = new Uint8Array(event.target.result);
                    processExcelData(data);
                };
                reader.readAsArrayBuffer(file);
            } else {
                alert('Please select a CSV or Excel file.');
            }
            
            // Reset the file input
            e.target.value = '';
        });

        // Process CSV data
        function processCSVData(csvData) {
            // Split the CSV into rows and parse
            const rows = csvData.split('\n');
            const headers = rows[0].split(',').map(header => header.trim());
            
            // Find column indices
            const idIndex = headers.findIndex(h => h.toLowerCase().includes('id') || h.toLowerCase().includes('machine'));
            const tempIndex = headers.findIndex(h => h.toLowerCase().includes('temp'));
            const vibIndex = headers.findIndex(h => h.toLowerCase().includes('vib'));
            
            if (idIndex === -1 || tempIndex === -1 || vibIndex === -1) {
                alert('CSV file must contain columns for Machine ID, Temperature, and Vibration only');
                return;
            }
            
            // Parse data rows
            const importedMachines = [];
            for (let i = 1; i < rows.length; i++) {
                if (!rows[i].trim()) continue;
                
                const cells = rows[i].split(',');
                const id = parseInt(cells[idIndex].trim());
                const temperature = parseFloat(cells[tempIndex].trim());
                const vibration = parseFloat(cells[vibIndex].trim());
                
                if (!isNaN(id) && !isNaN(temperature) && !isNaN(vibration)) {
                    importedMachines.push({ id, temperature, vibration });
                }
            }
            
            importMachineData(importedMachines);
        }

        // Process Excel data
        function processExcelData(data) {
            // Parse the Excel file
            const workbook = XLSX.read(data, { type: 'array' });
            const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
            const jsonData = XLSX.utils.sheet_to_json(firstSheet, { header: 1 });
            
            if (jsonData.length < 2) {
                alert('Excel file must contain at least a header row and one data row');
                return;
            }
            
            // Find column indices
            const headers = jsonData[0].map(h => String(h).toLowerCase());
            const idIndex = headers.findIndex(h => h.includes('id') || h.includes('machine'));
            const tempIndex = headers.findIndex(h => h.includes('temp'));
            const vibIndex = headers.findIndex(h => h.includes('vib'));
            
            if (idIndex === -1 || tempIndex === -1 || vibIndex === -1) {
                alert('Excel file must contain columns for Machine ID, Temperature, and Vibration only');
                return;
            }
            
            // Parse data rows
            const importedMachines = [];
            for (let i = 1; i < jsonData.length; i++) {
                const row = jsonData[i];
                if (!row || row.length === 0) continue;
                
                const id = parseInt(row[idIndex]);
                const temperature = parseFloat(row[tempIndex]);
                const vibration = parseFloat(row[vibIndex]);
                
                if (!isNaN(id) && !isNaN(temperature) && !isNaN(vibration)) {
                    importedMachines.push({ id, temperature, vibration });
                }
            }
            
            importMachineData(importedMachines);
        }

        // Import machine data into the application
        function importMachineData(importedMachines) {
            if (importedMachines.length === 0) {
                alert('No valid machine data found in the file');
                return;
            }
            
            // Update nextMachineId to be higher than any imported ID
            const highestId = Math.max(...importedMachines.map(m => m.id));
            nextMachineId = highestId + 1;
            
            // Replace existing machine data with imported data
            // Ensure only id, temperature, and vibration are included
            machineData = importedMachines.map(machine => ({
                id: machine.id,
                temperature: machine.temperature,
                vibration: machine.vibration
            }));
            
            // Reset selection
            selectedMachineId = null;
            document.getElementById('machine-details').classList.remove('active');
            
            // Update the UI
            renderFactory();
            createDataTable();
            
            alert(`Successfully imported ${importedMachines.length} machines`);
        }

        // Initialize
        function initializeMachines() {
            for (let i = 0; i < 6; i++) {
                const newMachine = {
                    id: nextMachineId++,
                    temperature: Math.floor(Math.random() * 100),
                    vibration: Math.floor(Math.random() * 100)
                };
                machineData.push(newMachine);
            }
            renderFactory();
            createDataTable();
        }

        // Start the application
        initializeMachines();